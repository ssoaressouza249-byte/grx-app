package com.grx.resolucao

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ResolutionDatabaseTest {

    @Test
    fun `all 28 models exist with 3 safe profiles within bounds`() {
        assertEquals(28, ResolutionDatabase.allModels.size)
        for (model in ResolutionDatabase.allModels) {
            assertEquals(3, model.profiles.size)
            for (profile in model.profiles) {
                assertTrue(
                    "Width ${profile.width} for ${model.name} must be >= 480",
                    profile.width >= ResolutionDatabase.MIN_SAFE_WIDTH
                )
                assertTrue(
                    "Height ${profile.height} for ${model.name} must be >= 800",
                    profile.height >= ResolutionDatabase.MIN_SAFE_HEIGHT
                )
                assertTrue(
                    "DPI ${profile.dpi} for ${model.name} must be in safe range",
                    profile.dpi in ResolutionDatabase.MIN_SAFE_DPI..ResolutionDatabase.MAX_SAFE_DPI
                )
            }
        }
    }

    @Test
    fun `searchModels finds Moto G04 and POCO X6 Pro`() {
        val motoResults = ResolutionDatabase.searchModels("G04")
        assertTrue(motoResults.any { it.name == "Moto G04" && it.formattedNative == "720x1612" })

        val pocoResults = ResolutionDatabase.searchModels("X6 Pro")
        assertTrue(pocoResults.any { it.name == "POCO X6 Pro" && it.formattedNative == "1220x2712" })
    }

    @Test
    fun `validateProfileBounds rejects unsafe width below 480px`() {
        val unsafe = ResolutionProfile(ProfileTier.LOW, 360, 800, 160)
        val error = ResolutionDatabase.validateProfileBounds(unsafe, 1080, 2400)
        assertNotNull(error)

        val safe = ResolutionProfile(ProfileTier.LOW, 540, 1200, 210)
        val noError = ResolutionDatabase.validateProfileBounds(safe, 1080, 2400)
        assertNull(noError)
    }
}
