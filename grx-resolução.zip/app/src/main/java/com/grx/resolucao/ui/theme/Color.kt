package com.grx.resolucao.ui.theme

import androidx.compose.ui.graphics.Color

val GrxDeepBlack = Color(0xFF050508)
val GrxSurfaceDark = Color(0xFF0C0E16)
val GrxSurfaceElevated = Color(0xFF131624)
val GrxNeonRed = Color(0xFFFF003C)
val GrxNeonRedSoft = Color(0x33FF003C)
val GrxElectricBlue = Color(0xFF00E5FF)
val GrxElectricBlueSoft = Color(0x2600E5FF)
val GrxNeonGreen = Color(0xFF00FF85)
val GrxNeonGreenSoft = Color(0x2600FF85)
val GrxAmberAlert = Color(0xFFFFB300)
val GrxTextPrimary = Color(0xFFF4F7FF)
val GrxTextSecondary = Color(0xFF98A6C0)
val GrxBorderMuted = Color(0xFF1E293B)
