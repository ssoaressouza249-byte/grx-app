package com.grx.resolucao

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.grx.resolucao.ui.theme.GrxResolucaoTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs

class FloatingResoService :
    Service(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    companion object {
        const val ACTION_START = "com.grx.resolucao.ACTION_START_OVERLAY"
        const val ACTION_STOP = "com.grx.resolucao.ACTION_STOP_OVERLAY"
        private const val NOTIFICATION_CHANNEL_ID = "grx_resolucao_overlay_channel"
        private const val NOTIFICATION_ID = 7701

        private val _isRunning = MutableStateFlow(false)
        val isRunning = _isRunning.asStateFlow()
    }

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    private lateinit var windowManager: WindowManager
    private var bubbleView: ComposeView? = null
    private var panelView: ComposeView? = null
    private var bubbleLayoutParams: WindowManager.LayoutParams? = null
    private var isPanelExpanded by mutableStateOf(false)

    override fun onCreate() {
        super.onCreate()
        savedStateController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        SafeResolutionManager.initialize(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = buildForegroundNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        _isRunning.value = true
        showFloatingBubble()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        _isRunning.value = false
        removeOverlayViews()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
        serviceScope.cancel()
        super.onDestroy()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showFloatingBubble() {
        if (bubbleView != null) return

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 260
        }
        bubbleLayoutParams = params

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        val composeBubble = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingResoService)
            setViewTreeViewModelStoreOwner(this@FloatingResoService)
            setViewTreeSavedStateRegistryOwner(this@FloatingResoService)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setContent {
                GrxResolucaoTheme {
                    val state by SafeResolutionManager.uiState.collectAsStateWithLifecycle()
                    FloatingBubbleBadge(
                        hasActiveCountdown = state.countdownSeconds != null,
                        countdownSeconds = state.countdownSeconds
                    )
                }
            }
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isDragging = false
                        true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                            isDragging = true
                        }
                        if (isDragging) {
                            params.x = initialX + dx
                            params.y = initialY + dy
                            try {
                                windowManager.updateViewLayout(this, params)
                            } catch (_: Throwable) {
                            }
                        }
                        true
                    }

                    MotionEvent.ACTION_UP -> {
                        if (!isDragging) {
                            expandFloatingPanel()
                        }
                        true
                    }

                    else -> false
                }
            }
        }

        bubbleView = composeBubble
        try {
            windowManager.addView(composeBubble, params)
        } catch (_: Throwable) {
            bubbleView = null
        }
    }

    private fun expandFloatingPanel() {
        if (panelView != null) return
        isPanelExpanded = true

        // Hide bubble while expanded so panel gets clean focus
        bubbleView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Throwable) {
            }
            bubbleView = null
        }

        SafeResolutionManager.refreshShizukuStatus()

        val displayMetrics = resources.displayMetrics
        val panelWidthPx = minOf((displayMetrics.widthPixels * 0.92f).toInt(), (420 * displayMetrics.density).toInt())

        val params = WindowManager.LayoutParams(
            panelWidthPx,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        val composePanel = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingResoService)
            setViewTreeViewModelStoreOwner(this@FloatingResoService)
            setViewTreeSavedStateRegistryOwner(this@FloatingResoService)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setContent {
                GrxResolucaoTheme {
                    val state by SafeResolutionManager.uiState.collectAsStateWithLifecycle()
                    FloatingControlPanel(
                        uiState = state,
                        onMinimize = { collapseToBubble() },
                        onCloseService = { stopSelf() },
                        onApplyProfile = { deviceName, profile ->
                            SafeResolutionManager.applyProfile(deviceName, profile)
                        },
                        onConfirmApplied = {
                            SafeResolutionManager.confirmAppliedResolution()
                        },
                        onResetDefault = {
                            SafeResolutionManager.resetToDefault()
                        },
                        onRefreshStatus = {
                            serviceScope.launch {
                                SafeResolutionManager.refreshDisplayStatus()
                            }
                        },
                        onRequestShizukuPermission = {
                            SafeResolutionManager.requestShizukuPermission()
                        }
                    )
                }
            }
        }

        panelView = composePanel
        try {
            windowManager.addView(composePanel, params)
        } catch (_: Throwable) {
            panelView = null
            showFloatingBubble()
        }
    }

    private fun collapseToBubble() {
        isPanelExpanded = false
        panelView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Throwable) {
            }
            panelView = null
        }
        showFloatingBubble()
    }

    private fun removeOverlayViews() {
        bubbleView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Throwable) {
            }
            bubbleView = null
        }
        panelView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Throwable) {
            }
            panelView = null
        }
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java) ?: return
        val channel = NotificationChannel(
            NOTIFICATION_CHANNEL_ID,
            getString(R.string.overlay_notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.overlay_notification_channel_desc)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildForegroundNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FloatingResoService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setContentIntent(openAppIntent)
            .addAction(0, "Encerrar", stopIntent)
            .setOngoing(true)
            .build()
    }
}
