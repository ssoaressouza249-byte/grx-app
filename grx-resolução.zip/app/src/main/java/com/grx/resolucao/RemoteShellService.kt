package com.grx.resolucao

import androidx.annotation.Keep
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.system.exitProcess

/**
 * Privileged Shizuku UserService running in shell/root context to execute
 * validated wm size and wm density commands safely.
 */
@Keep
class RemoteShellService : IRemoteShellService.Stub() {

    override fun exec(command: String): String {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val stdout = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText() }
            val exitCode = process.waitFor()
            if (exitCode == 0) {
                stdout.trim()
            } else {
                "ERR($exitCode): ${stderr.ifBlank { stdout }.trim()}"
            }
        } catch (t: Throwable) {
            "ERR: ${t.message ?: "Execution failed"}"
        }
    }

    override fun destroy() {
        exitProcess(0)
    }
}
