package com.grx.resolucao

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.Minimize
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.grx.resolucao.ui.theme.GrxAmberAlert
import com.grx.resolucao.ui.theme.GrxDeepBlack
import com.grx.resolucao.ui.theme.GrxElectricBlue
import com.grx.resolucao.ui.theme.GrxElectricBlueSoft
import com.grx.resolucao.ui.theme.GrxNeonGreen
import com.grx.resolucao.ui.theme.GrxNeonGreenSoft
import com.grx.resolucao.ui.theme.GrxNeonRed
import com.grx.resolucao.ui.theme.GrxNeonRedSoft
import com.grx.resolucao.ui.theme.GrxSurfaceDark
import com.grx.resolucao.ui.theme.GrxSurfaceElevated
import com.grx.resolucao.ui.theme.GrxTextPrimary
import com.grx.resolucao.ui.theme.GrxTextSecondary

@Composable
fun FloatingBubbleBadge(
    hasActiveCountdown: Boolean,
    countdownSeconds: Int?,
    modifier: Modifier = Modifier
) {
    val borderBrush = Brush.linearGradient(
        colors = listOf(GrxElectricBlue, GrxNeonRed)
    )
    Box(
        modifier = modifier
            .size(60.dp)
            .clip(CircleShape)
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(GrxNeonRed, Color(0xFF900022), GrxDeepBlack)
                )
            )
            .border(width = 2.dp, brush = borderBrush, shape = CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = if (hasActiveCountdown && countdownSeconds != null) "${countdownSeconds}s" else "GRX",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontSize = 13.sp,
                    letterSpacing = 1.sp
                ),
                color = GrxTextPrimary
            )
            Text(
                text = if (hasActiveCountdown) "LOCK" else "RES",
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 8.sp),
                color = GrxElectricBlue
            )
        }
    }
}

@Composable
fun FloatingControlPanel(
    uiState: ResolutionManagerUiState,
    onMinimize: () -> Unit,
    onCloseService: () -> Unit,
    onApplyProfile: (String, ResolutionProfile) -> Unit,
    onConfirmApplied: () -> Unit,
    onResetDefault: () -> Unit,
    onRefreshStatus: () -> Unit,
    onRequestShizukuPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedBrandTab1 by remember { mutableStateOf<DeviceBrand?>(null) }
    var selectedModelTab1 by remember { mutableStateOf<DeviceModel?>(null) }
    var selectedModelTab2 by remember { mutableStateOf<DeviceModel?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    Surface(
        modifier = modifier
            .widthIn(max = 420.dp)
            .fillMaxWidth()
            .heightIn(min = 430.dp, max = 560.dp)
            .border(
                width = 2.dp,
                color = GrxElectricBlue,
                shape = RoundedCornerShape(18.dp)
            ),
        shape = RoundedCornerShape(18.dp),
        color = GrxDeepBlack,
        shadowElevation = 16.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(GrxNeonRedSoft)
                            .border(1.5.dp, GrxNeonRed, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DisplaySettings,
                            contentDescription = "GRX Logo",
                            tint = GrxNeonRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "GRX RESOLUÇÃO",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.1.sp
                            ),
                            color = GrxTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = when (uiState.shizukuState) {
                                ShizukuConnectionState.CONNECTED_READY -> "SHIZUKU ONLINE • MODO SEGURO"
                                ShizukuConnectionState.PERMISSION_REQUIRED -> "SHIZUKU AGUARDANDO PERMISSÃO"
                                ShizukuConnectionState.DISCONNECTED -> "SHIZUKU DESCONECTADO"
                            },
                            style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp),
                            color = when (uiState.shizukuState) {
                                ShizukuConnectionState.CONNECTED_READY -> GrxNeonGreen
                                ShizukuConnectionState.PERMISSION_REQUIRED -> GrxAmberAlert
                                ShizukuConnectionState.DISCONNECTED -> GrxNeonRed
                            }
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onMinimize,
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("panel_minimize_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Minimize,
                            contentDescription = "Minimizar para bolha",
                            tint = GrxElectricBlue
                        )
                    }
                    IconButton(
                        onClick = onCloseService,
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("panel_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Fechar painel flutuante",
                            tint = GrxNeonRed
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 15-second Anti-Fail Lock Banner (visible on all tabs when active)
            AnimatedVisibility(visible = uiState.countdownSeconds != null) {
                uiState.countdownSeconds?.let { seconds ->
                    AntiFailCountdownBanner(
                        secondsRemaining = seconds,
                        pendingProfile = uiState.pendingProfile,
                        pendingDeviceName = uiState.pendingDeviceName,
                        onConfirm = onConfirmApplied,
                        onRevert = onResetDefault
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            // Feedback Banner
            val feedbackText = uiState.lastErrorMessage ?: uiState.lastAppliedMessage
            val isError = uiState.lastErrorMessage != null
            if (feedbackText != null && uiState.countdownSeconds == null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isError) GrxNeonRedSoft else GrxElectricBlueSoft)
                        .border(
                            1.dp,
                            if (isError) GrxNeonRed else GrxElectricBlue,
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = feedbackText,
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                        color = GrxTextPrimary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // 3 Internal Gamer Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(GrxSurfaceDark)
                    .border(1.5.dp, GrxElectricBlue.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                GamerTabButton(
                    title = "Principais & IA",
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tab_principais")
                )
                GamerTabButton(
                    title = "Todas & Busca",
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tab_busca")
                )
                GamerTabButton(
                    title = "Status & Reset",
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tab_status")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Tab Body
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTab) {
                    0 -> TabPrincipaisAi(
                        detectedDevice = uiState.detectedDevice,
                        selectedBrand = selectedBrandTab1,
                        selectedModel = selectedModelTab1,
                        isApplying = uiState.isApplying,
                        onSelectBrand = {
                            selectedBrandTab1 = it
                            selectedModelTab1 = null
                        },
                        onSelectModel = { selectedModelTab1 = it },
                        onBackFromModel = { selectedModelTab1 = null },
                        onBackFromBrand = { selectedBrandTab1 = null },
                        onApplyProfile = onApplyProfile
                    )

                    1 -> TabTodasBusca(
                        searchQuery = searchQuery,
                        onSearchQueryChange = { searchQuery = it },
                        selectedModel = selectedModelTab2,
                        isApplying = uiState.isApplying,
                        onSelectModel = { selectedModelTab2 = it },
                        onBackFromModel = { selectedModelTab2 = null },
                        onApplyProfile = onApplyProfile
                    )

                    2 -> TabStatusReset(
                        uiState = uiState,
                        onConfirmApplied = onConfirmApplied,
                        onResetDefault = onResetDefault,
                        onRefreshStatus = onRefreshStatus,
                        onRequestShizukuPermission = onRequestShizukuPermission
                    )
                }
            }
        }
    }
}

@Composable
private fun GamerTabButton(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(38.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) GrxNeonRed else Color.Transparent)
            .border(
                width = if (selected) 1.dp else 0.dp,
                color = if (selected) GrxElectricBlue else Color.Transparent,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            ),
            color = if (selected) GrxTextPrimary else GrxTextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun AntiFailCountdownBanner(
    secondsRemaining: Int,
    pendingProfile: ResolutionProfile?,
    pendingDeviceName: String?,
    onConfirm: () -> Unit,
    onRevert: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A0710)),
        border = BorderStroke(1.5.dp, GrxNeonRed),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WarningAmber,
                        contentDescription = "Alerta Anti-Falha",
                        tint = GrxAmberAlert,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "TRAVA ANTI-FALHA: ${secondsRemaining}s",
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                        color = GrxAmberAlert
                    )
                }
                if (pendingProfile != null) {
                    Text(
                        text = "${pendingProfile.formattedSize} • ${pendingProfile.formattedDpi}",
                        style = MaterialTheme.typography.labelMedium,
                        color = GrxElectricBlue
                    )
                }
            }
            if (!pendingDeviceName.isNullOrBlank()) {
                Text(
                    text = "Perfil: $pendingDeviceName (${pendingProfile?.tier?.shortLabel ?: ""})",
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                    color = GrxTextSecondary
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { secondsRemaining / 15f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = GrxNeonRed,
                trackColor = GrxSurfaceElevated
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onConfirm,
                    colors = ButtonDefaults.buttonColors(containerColor = GrxNeonGreen),
                    contentPadding = PaddingValues(vertical = 8.dp, horizontal = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .testTag("confirm_resolution_button")
                ) {
                    Text(
                        text = "CONFIRMAR",
                        style = MaterialTheme.typography.labelMedium,
                        color = GrxDeepBlack
                    )
                }
                OutlinedButton(
                    onClick = onRevert,
                    border = BorderStroke(1.5.dp, GrxNeonRed),
                    contentPadding = PaddingValues(vertical = 8.dp, horizontal = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .testTag("revert_resolution_button")
                ) {
                    Text(
                        text = "REVERTER",
                        style = MaterialTheme.typography.labelMedium,
                        color = GrxNeonRed
                    )
                }
            }
        }
    }
}

@Composable
private fun TabPrincipaisAi(
    detectedDevice: DetectedDeviceResult?,
    selectedBrand: DeviceBrand?,
    selectedModel: DeviceModel?,
    isApplying: Boolean,
    onSelectBrand: (DeviceBrand) -> Unit,
    onSelectModel: (DeviceModel) -> Unit,
    onBackFromModel: () -> Unit,
    onBackFromBrand: () -> Unit,
    onApplyProfile: (String, ResolutionProfile) -> Unit
) {
    if (selectedModel != null) {
        ModelProfileSelector(
            model = selectedModel,
            isApplying = isApplying,
            onBack = onBackFromModel,
            onApply = { profile -> onApplyProfile(selectedModel.name, profile) }
        )
        return
    }

    if (selectedBrand != null) {
        val brandModels = remember(selectedBrand) { ResolutionDatabase.modelsForBrand(selectedBrand) }
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onBackFromBrand)
                    .padding(vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Voltar",
                    tint = GrxElectricBlue,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Modelos ${selectedBrand.displayName}",
                    style = MaterialTheme.typography.titleMedium,
                    color = GrxElectricBlue
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(brandModels, key = { it.id }) { model ->
                    DeviceModelRowCard(model = model, onClick = { onSelectModel(model) })
                }
            }
        }
        return
    }

    // Main Tab 1 Landing: AI Detection Card + 3 Big Brand Buttons (Motorola, POCO, Samsung)
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        if (detectedDevice != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = GrxSurfaceDark),
                    border = BorderStroke(1.5.dp, GrxElectricBlue),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "Assistente IA",
                                    tint = GrxElectricBlue,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "ASSISTENTE IA • SEU CELULAR",
                                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                                    color = GrxElectricBlue
                                )
                            }
                            Text(
                                text = if (detectedDevice.isKnownModel) "BASE OFICIAL" else "AUTO-CALIBRADO",
                                style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp),
                                color = GrxNeonGreen,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(GrxNeonGreenSoft)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = detectedDevice.effectiveModel.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = GrxTextPrimary
                        )
                        Text(
                            text = "Nativa Detectada: ${detectedDevice.physicalWidth}x${detectedDevice.physicalHeight} • ${detectedDevice.stableDpi} DPI",
                            style = MaterialTheme.typography.labelMedium,
                            color = GrxTextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { onSelectModel(detectedDevice.effectiveModel) },
                            colors = ButtonDefaults.buttonColors(containerColor = GrxNeonRed),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                                .testTag("ai_detected_select_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = GrxTextPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "CALIBRAR ESTE APARELHO",
                                style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                                color = GrxTextPrimary
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "MARCAS PRINCIPAIS",
                style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                color = GrxTextSecondary,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        items(ResolutionDatabase.primaryBrands, key = { it.name }) { brand ->
            val count = ResolutionDatabase.modelsForBrand(brand).size
            PrimaryBrandBigButton(
                brand = brand,
                modelCount = count,
                onClick = { onSelectBrand(brand) }
            )
        }
    }
}

@Composable
private fun PrimaryBrandBigButton(
    brand: DeviceBrand,
    modelCount: Int,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = GrxSurfaceElevated),
        border = BorderStroke(1.5.dp, GrxElectricBlue),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("brand_button_${brand.name.lowercase()}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(GrxNeonRedSoft)
                        .border(1.dp, GrxNeonRed, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = brand.displayName,
                        tint = GrxNeonRed,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = brand.displayName.uppercase(),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = GrxTextPrimary
                    )
                    Text(
                        text = "$modelCount modelos pré-calibrados",
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                        color = GrxTextSecondary
                    )
                }
            }
            Text(
                text = "ABRIR →",
                style = MaterialTheme.typography.labelMedium,
                color = GrxElectricBlue
            )
        }
    }
}

@Composable
private fun TabTodasBusca(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    selectedModel: DeviceModel?,
    isApplying: Boolean,
    onSelectModel: (DeviceModel) -> Unit,
    onBackFromModel: () -> Unit,
    onApplyProfile: (String, ResolutionProfile) -> Unit
) {
    if (selectedModel != null) {
        ModelProfileSelector(
            model = selectedModel,
            isApplying = isApplying,
            onBack = onBackFromModel,
            onApply = { profile -> onApplyProfile(selectedModel.name, profile) }
        )
        return
    }

    val filteredModels = remember(searchQuery) {
        ResolutionDatabase.searchModels(searchQuery)
    }
    val grouped = remember(filteredModels) {
        ResolutionDatabase.allBrandsOrdered
            .map { brand -> brand to filteredModels.filter { it.brand == brand } }
            .filter { it.second.isNotEmpty() }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = {
                Text(
                    text = "Buscar modelo (ex: Moto G04, POCO X6, A54)...",
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                    color = GrxTextSecondary
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Buscar",
                    tint = GrxElectricBlue
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Limpar busca",
                            tint = GrxNeonRed
                        )
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GrxElectricBlue,
                unfocusedBorderColor = GrxElectricBlue.copy(alpha = 0.5f),
                focusedTextColor = GrxTextPrimary,
                unfocusedTextColor = GrxTextPrimary,
                cursorColor = GrxNeonRed,
                focusedContainerColor = GrxSurfaceDark,
                unfocusedContainerColor = GrxSurfaceDark
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_model_input")
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (grouped.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Nenhum modelo encontrado para \"$searchQuery\".\nUse o Assistente IA na Aba 1 para calibração automática.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = GrxTextSecondary
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                grouped.forEach { (brand, models) ->
                    item(key = "header_${brand.name}") {
                        Text(
                            text = brand.displayName.uppercase(),
                            style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                            color = GrxNeonRed,
                            modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                        )
                    }
                    items(models, key = { it.id }) { model ->
                        DeviceModelRowCard(model = model, onClick = { onSelectModel(model) })
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceModelRowCard(
    model: DeviceModel,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = GrxSurfaceDark),
        border = BorderStroke(1.5.dp, GrxElectricBlue.copy(alpha = 0.7f)),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("model_card_${model.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = model.name,
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp),
                    color = GrxTextPrimary
                )
                Text(
                    text = "Nativa: ${model.formattedNative} • ${model.nativeDpi} DPI",
                    style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp),
                    color = GrxTextSecondary
                )
            }
            Text(
                text = "3 PERFIS",
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp),
                color = GrxElectricBlue,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(GrxElectricBlueSoft)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun ModelProfileSelector(
    model: DeviceModel,
    isApplying: Boolean,
    onBack: () -> Unit,
    onApply: (ResolutionProfile) -> Unit
) {
    var selectedTier by remember(model.id) { mutableStateOf(ProfileTier.LOW) }
    val activeProfile = model.profiles.first { it.tier == selectedTier }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onBack)
                .padding(vertical = 4.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Voltar",
                tint = GrxElectricBlue,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = model.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = GrxTextPrimary
                )
                Text(
                    text = "${model.brand.displayName} • Nativa ${model.formattedNative}",
                    style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp),
                    color = GrxElectricBlue
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(model.profiles, key = { it.tier.name }) { profile ->
                val isSelected = profile.tier == selectedTier
                Card(
                    onClick = { selectedTier = profile.tier },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFF1A0710) else GrxSurfaceDark
                    ),
                    border = BorderStroke(
                        width = if (isSelected) 2.dp else 1.5.dp,
                        color = if (isSelected) GrxNeonRed else GrxElectricBlue.copy(alpha = 0.6f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_card_${profile.tier.name.lowercase()}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = when (profile.tier) {
                                        ProfileTier.LOW -> Icons.Default.Speed
                                        ProfileTier.MEDIUM -> Icons.Default.Tune
                                        ProfileTier.HIGH -> Icons.Default.DisplaySettings
                                    },
                                    contentDescription = profile.tier.label,
                                    tint = if (isSelected) GrxNeonRed else GrxElectricBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = profile.tier.label,
                                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp),
                                    color = if (isSelected) GrxNeonRed else GrxTextPrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "${profile.formattedSize}  •  ${profile.formattedDpi}",
                                style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.sp),
                                color = GrxElectricBlue
                            )
                        }

                        Text(
                            text = profile.tier.badgeText,
                            style = MaterialTheme.typography.labelMedium.copy(fontSize = 9.sp),
                            color = if (isSelected) GrxTextPrimary else GrxTextSecondary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) GrxNeonRed else GrxSurfaceElevated)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = { onApply(activeProfile) },
            enabled = !isApplying,
            colors = ButtonDefaults.buttonColors(containerColor = GrxNeonRed),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("apply_resolution_button")
        ) {
            if (isApplying) {
                CircularProgressIndicator(
                    color = GrxTextPrimary,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                Text(
                    text = "APLICAR RESOLUÇÃO (${activeProfile.formattedSize})",
                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                    color = GrxTextPrimary
                )
            }
        }
    }
}

@Composable
private fun TabStatusReset(
    uiState: ResolutionManagerUiState,
    onConfirmApplied: () -> Unit,
    onResetDefault: () -> Unit,
    onRefreshStatus: () -> Unit,
    onRequestShizukuPermission: () -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GrxSurfaceDark),
                border = BorderStroke(1.5.dp, GrxElectricBlue),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "STATUS ATIVO DA TELA",
                            style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                            color = GrxElectricBlue
                        )
                        IconButton(
                            onClick = onRefreshStatus,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Atualizar leitura",
                                tint = GrxElectricBlue,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    HorizontalDivider(color = GrxElectricBlue.copy(alpha = 0.25f))
                    Spacer(modifier = Modifier.height(8.dp))
                    StatusRow("Resolução Ativa", uiState.displaySnapshot.activeSizeLabel, GrxTextPrimary)
                    StatusRow("Densidade Ativa", uiState.displaySnapshot.activeDpiLabel, GrxTextPrimary)
                    StatusRow("Painel Físico", uiState.displaySnapshot.physicalSize, GrxTextSecondary)
                }
            }
        }

        item {
            val isReady = uiState.shizukuState == ShizukuConnectionState.CONNECTED_READY
            Card(
                colors = CardDefaults.cardColors(containerColor = GrxSurfaceDark),
                border = BorderStroke(
                    1.5.dp,
                    if (isReady) GrxNeonGreen else GrxNeonRed
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isReady) Icons.Default.CheckCircle else Icons.Default.Security,
                            contentDescription = "Status Shizuku",
                            tint = if (isReady) GrxNeonGreen else GrxNeonRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (uiState.shizukuState) {
                                ShizukuConnectionState.CONNECTED_READY -> "Shizuku Conectado e Autorizado"
                                ShizukuConnectionState.PERMISSION_REQUIRED -> "Shizuku: Autorização Necessária"
                                ShizukuConnectionState.DISCONNECTED -> "Shizuku Desconectado"
                            },
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp),
                            color = if (isReady) GrxNeonGreen else GrxNeonRed
                        )
                    }
                    if (!isReady) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = onRequestShizukuPermission,
                            border = BorderStroke(1.5.dp, GrxElectricBlue),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "SOLICITAR / RECONECTAR SHIZUKU",
                                style = MaterialTheme.typography.labelMedium,
                                color = GrxElectricBlue
                            )
                        }
                    }
                }
            }
        }

        if (uiState.countdownSeconds != null) {
            item {
                AntiFailCountdownBanner(
                    secondsRemaining = uiState.countdownSeconds,
                    pendingProfile = uiState.pendingProfile,
                    pendingDeviceName = uiState.pendingDeviceName,
                    onConfirm = onConfirmApplied,
                    onRevert = onResetDefault
                )
            }
        }

        item {
            Button(
                onClick = onResetDefault,
                enabled = !uiState.isApplying,
                colors = ButtonDefaults.buttonColors(containerColor = GrxNeonRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("restore_original_button")
            ) {
                Icon(
                    imageVector = Icons.Default.RestartAlt,
                    contentDescription = "Restaurar",
                    tint = GrxTextPrimary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "RESTAURAR RESOLUÇÃO ORIGINAL",
                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                    color = GrxTextPrimary
                )
            }
        }
    }
}

@Composable
private fun StatusRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = GrxTextSecondary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = valueColor
        )
    }
}
