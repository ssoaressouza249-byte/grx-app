package com.grx.resolucao.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val GrxDarkColorScheme = darkColorScheme(
    primary = GrxNeonRed,
    onPrimary = GrxTextPrimary,
    primaryContainer = GrxNeonRedSoft,
    onPrimaryContainer = GrxTextPrimary,
    secondary = GrxElectricBlue,
    onSecondary = GrxDeepBlack,
    secondaryContainer = GrxElectricBlueSoft,
    onSecondaryContainer = GrxElectricBlue,
    tertiary = GrxNeonGreen,
    onTertiary = GrxDeepBlack,
    background = GrxDeepBlack,
    onBackground = GrxTextPrimary,
    surface = GrxSurfaceDark,
    onSurface = GrxTextPrimary,
    surfaceVariant = GrxSurfaceElevated,
    onSurfaceVariant = GrxTextSecondary,
    outline = GrxElectricBlue,
    outlineVariant = GrxBorderMuted,
    error = GrxNeonRed,
    onError = GrxTextPrimary
)

private val GrxShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp)
)

@Composable
fun GrxResolucaoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GrxDarkColorScheme,
        typography = GrxTypography,
        shapes = GrxShapes,
        content = content
    )
}
