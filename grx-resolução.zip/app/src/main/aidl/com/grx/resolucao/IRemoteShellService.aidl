package com.grx.resolucao;

interface IRemoteShellService {
    void destroy() = 16777114;
    String exec(String command) = 1;
}
